<!DOCTYPE html>
	<!--[if IE 8]>
		<html xmlns="http://www.w3.org/1999/xhtml" class="ie8" lang="en-US">
	<![endif]-->
	<!--[if !(IE 8) ]><!-->
		<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
	<!--<![endif]-->
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Log In &lsaquo; Go Courier &#8212; WordPress</title>
	<link rel='dns-prefetch' href='//s.w.org' />
<script type='text/javascript'>
/* <![CDATA[ */
var ajax_login_object = {"ajaxurl":"http:\/\/event-theme.com\/themes\/gocourierwp\/wp-admin\/admin-ajax.php","redirecturl":"http:\/\/event-theme.com\/themes\/gocourierwp\/","loadingmessage":"Sending user info, please wait..."};
/* ]]> */
</script>
<script type='text/javascript' src='http://event-theme.com/themes/gocourierwp/wp-admin/load-scripts.php?c=0&amp;load%5B%5D=jquery-core,jquery-migrate&amp;ver=4.9.8'></script>
<script type='text/javascript' src='http://event-theme.com/themes/gocourierwp/wp-content/themes/gocourier/js/ajax-login-script.js?ver=4.9.8'></script>
<link rel='stylesheet' href='http://event-theme.com/themes/gocourierwp/wp-admin/load-styles.php?c=0&amp;dir=ltr&amp;load%5B%5D=dashicons,buttons,forms,l10n,login&amp;ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='gocourier-custom-admin-style-css'  href='http://event-theme.com/themes/gocourierwp/wp-content/themes/gocourier/admin/assets/css/custom_admin_style.css?ver=4.9.8' type='text/css' media='all' />
<style id='gocourier-custom-admin-style-inline-css' type='text/css'>
body.login div#login h1 a {
            background-image: url(http://event-theme.com/themes/gocourierwp/wp-content/themes/gocourier/images/logo.png);
            background-position: bottom center;
			background-size: auto auto;
			margin: 0 auto 15px;
			width: auto;
        }
</style>
<meta name='robots' content='noindex,follow' />
	<meta name="viewport" content="width=device-width" />
	<link rel="icon" href="http://event-theme.com/themes/gocourierwp/wp-content/uploads/2016/05/cropped-cropped-logo-2-150x150.jpg" sizes="32x32" />
<link rel="icon" href="http://event-theme.com/themes/gocourierwp/wp-content/uploads/2016/05/cropped-cropped-logo-2-300x300.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://event-theme.com/themes/gocourierwp/wp-content/uploads/2016/05/cropped-cropped-logo-2-180x180.jpg" />
<meta name="msapplication-TileImage" content="http://event-theme.com/themes/gocourierwp/wp-content/uploads/2016/05/cropped-cropped-logo-2-300x300.jpg" />
	</head>
	<body class="login login-action-login wp-core-ui  locale-en-us">
		<div id="login">
		<h1><a href="https://wordpress.org/" title="Powered by WordPress" tabindex="-1">Powered by WordPress</a></h1>
	
<form name="loginform" id="loginform" action="http://event-theme.com/themes/gocourierwp/wp-login.php" method="post">
	<p>
		<label for="user_login">Username or Email Address<br />
		<input type="text" name="log" id="user_login" class="input" value="" size="20" /></label>
	</p>
	<p>
		<label for="user_pass">Password<br />
		<input type="password" name="pwd" id="user_pass" class="input" value="" size="20" /></label>
	</p>
		<p class="forgetmenot"><label for="rememberme"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> Remember Me</label></p>
	<p class="submit">
		<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="Log In" />
		<input type="hidden" name="redirect_to" value="http://event-theme.com/themes/gocourierwp/wp-admin/" />
		<input type="hidden" name="testcookie" value="1" />
	</p>
</form>

<p id="nav">
	<a href="http://event-theme.com/themes/gocourierwp/my-account/lost-password/">Lost your password?</a>
</p>

<script type="text/javascript">
function wp_attempt_focus(){
setTimeout( function(){ try{
d = document.getElementById('user_login');
d.focus();
d.select();
} catch(e){}
}, 200);
}

wp_attempt_focus();
if(typeof wpOnload=='function')wpOnload();
</script>

	<p id="backtoblog"><a href="http://event-theme.com/themes/gocourierwp/">&larr; Back to Go Courier</a></p>
		
	</div>

	
		<div class="clear"></div>
	</body>
	</html>
	